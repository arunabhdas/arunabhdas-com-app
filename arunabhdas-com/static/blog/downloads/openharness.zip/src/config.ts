import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";

export type Mode = "ask" | "write" | "yolo";
export type Priority = "P0" | "P1" | "P2" | "P3";
export type Rule = { name: string; pattern: string; message: string };

export type Config = {
  mode: Mode;
  protect: string[];
  frozen: string[];
  verify: string[];
  maxRetries: number;
  hashline: boolean;
  rules: Rule[];
  review: { enabled: boolean; model?: string; blockOn: Priority[] };
};

export const defaults: Config = {
  mode: "write",
  protect: [".env*", "*.pem", "secrets/**", ".git/**"],
  frozen: [],
  verify: [],
  maxRetries: 3,
  hashline: true,
  rules: [],
  review: { enabled: true, blockOn: ["P0", "P1"] },
};

/** A broken harness.json throws. Callers must fail closed, not fall back to defaults. */
export function loadConfig(cwd: string): Config {
  const file = join(cwd, "harness.json");
  if (!existsSync(file)) return defaults;

  const raw = JSON.parse(readFileSync(file, "utf8")) as Partial<Config>;
  const config = { ...defaults, ...raw, review: { ...defaults.review, ...raw.review } };

  if (!["ask", "write", "yolo"].includes(config.mode)) {
    throw new Error(`harness.json: unknown mode "${config.mode}"`);
  }
  for (const rule of config.rules) new RegExp(rule.pattern);
  return config;
}
