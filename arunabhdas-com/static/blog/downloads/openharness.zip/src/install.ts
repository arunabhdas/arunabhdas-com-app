import type { ExtensionAPI, ModelRuntime } from "@earendil-works/pi-coding-agent";
import { installDelegate } from "./features/delegate.ts";
import { installEdits } from "./features/edits.ts";
import { installGates } from "./features/gates.ts";
import { installGuard } from "./features/guard.ts";
import { installLedger } from "./features/ledger.ts";
import { installPlan } from "./features/plan.ts";
import { installStreamRules } from "./features/stream-rules.ts";
import { HarnessState } from "./state.ts";

export type InstallOptions = { state?: HarnessState; modelRuntime?: ModelRuntime };

export function install(pi: ExtensionAPI, { state = new HarnessState(), modelRuntime }: InstallOptions = {}) {
  installGuard(pi, state);
  installEdits(pi, state);
  installStreamRules(pi, state);
  installPlan(pi, state);
  installDelegate(pi, state, modelRuntime);
  installGates(pi, state, modelRuntime);
  installLedger(pi, state);
  return state;
}
