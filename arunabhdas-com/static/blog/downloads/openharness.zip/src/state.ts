import { appendFileSync, mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { type Config, loadConfig } from "./config.ts";

export type Status = "idle" | "unchanged" | "passed" | "failed";
export type LedgerEntry = { kind: string; [key: string]: unknown };

/** One object shared by every feature in a session. */
export class HarnessState {
  status: Status = "idle";
  planning = false;
  expectChange = false;
  entries: LedgerEntry[] = [];
  private loaded?: { config?: Config; error?: string };
  private cwd?: string;
  private runId = new Date().toISOString().replace(/[:.]/g, "-");

  /** Loaded once, on first use, because extensions only learn the cwd from an event. */
  load(cwd: string) {
    if (this.loaded) return this.loaded;
    this.cwd = cwd;
    try {
      this.loaded = { config: loadConfig(cwd) };
    } catch (error) {
      this.loaded = { error: String(error) };
    }
    return this.loaded;
  }

  /** The harness's own folder ignores itself, so it never looks like a code change. */
  folder(name = "") {
    const root = join(this.cwd ?? process.cwd(), ".openharness");
    mkdirSync(join(root, name), { recursive: true });
    writeFileSync(join(root, ".gitignore"), "*\n");
    return join(root, name);
  }

  record(entry: LedgerEntry) {
    this.entries.push(entry);
    const line = JSON.stringify({ at: new Date().toISOString(), ...entry });
    appendFileSync(join(this.folder("runs"), `${this.runId}.jsonl`), `${line}\n`);
  }
}
