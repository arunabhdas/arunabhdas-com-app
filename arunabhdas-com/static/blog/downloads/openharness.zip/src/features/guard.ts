import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { decide, tierOf } from "../policy.ts";
import type { HarnessState } from "../state.ts";

export function installGuard(pi: ExtensionAPI, state: HarnessState) {
  pi.on("tool_call", async (event, ctx) => {
    const { config, error } = state.load(ctx.cwd);

    // Fail closed: with a broken policy file, only reads get through.
    if (!config) {
      if (tierOf(event.toolName) === "read") return undefined;
      return { block: true, reason: `Blocked: ${error}` };
    }

    const verdict = decide({ tool: event.toolName, input: event.input }, config, ctx.cwd);
    if (verdict.decision === "allow") return undefined;

    if (verdict.decision === "ask" && ctx.hasUI) {
      const yes = await ctx.ui.confirm("OpenHarness", `${event.toolName}: ${verdict.reason}. Allow it?`);
      if (yes) return undefined;
    }

    state.record({ kind: "blocked", tool: event.toolName, reason: verdict.reason });
    return { block: true, reason: `Blocked by OpenHarness: ${verdict.reason}.` };
  });
}
