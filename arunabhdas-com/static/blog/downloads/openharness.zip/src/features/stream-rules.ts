import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { firstHit, produced, type Rule } from "../rules.ts";
import type { HarnessState } from "../state.ts";

export function installStreamRules(pi: ExtensionAPI, state: HarnessState) {
  const fired = new Set<string>();
  let pending: Rule | undefined;
  let dropped: number | undefined;

  pi.on("input", () => fired.clear());

  // Watch the stream. On a match, stop the model mid-sentence.
  pi.on("message_update", (event, ctx) => {
    if (pending || event.message.role !== "assistant") return;
    const rules = state.load(ctx.cwd).config?.rules ?? [];
    const hit = firstHit(produced(event.message.content), rules, fired);
    if (!hit) return;
    pending = hit;
    dropped = event.message.timestamp;
    fired.add(hit.name);
    state.record({ kind: "rule", rule: hit.name });
    ctx.abort();
  });

  // The time travel: the bad attempt never reaches the model again.
  pi.on("context", (event) => {
    if (dropped === undefined) return;
    const kept = event.messages.filter((m) => !(m.role === "assistant" && m.timestamp === dropped));
    return { messages: kept };
  });

  // Once the run has stopped, retry with the rule in hand.
  pi.on("agent_settled", () => {
    if (!pending) return;
    const rule = pending;
    pending = undefined;
    pi.sendMessage(
      {
        customType: "openharness-rule",
        content: `Rule "${rule.name}": ${rule.message} Your last attempt was discarded. Try again.`,
        display: true,
      },
      { triggerTurn: true },
    );
  });
}
