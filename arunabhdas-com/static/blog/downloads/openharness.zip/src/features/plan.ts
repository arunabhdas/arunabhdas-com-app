import { writeFileSync } from "node:fs";
import { join } from "node:path";
import { defineTool, type ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import type { HarnessState } from "../state.ts";

const READ_ONLY = ["read", "grep", "find", "ls", "submit_plan"];

export function installPlan(pi: ExtensionAPI, state: HarnessState) {
  let previous: string[] = [];

  pi.registerTool(
    defineTool({
      name: "submit_plan",
      label: "Submit plan",
      description: "Submit the finished plan for approval. Call this once, when planning is done.",
      parameters: Type.Object({
        goal: Type.String(),
        steps: Type.Array(Type.String(), { minItems: 1 }),
        verification: Type.String({ description: "How we will know it worked" }),
      }),
      async execute(_id, plan, _signal, _update, ctx) {
        const text = [`# ${plan.goal}`, "", ...plan.steps.map((s, i) => `${i + 1}. ${s}`), "", `Verify: ${plan.verification}`];
        writeFileSync(join(state.folder(), "plan.md"), `${text.join("\n")}\n`);
        state.record({ kind: "plan", goal: plan.goal, steps: plan.steps.length });

        const approved = ctx.hasUI ? await ctx.ui.confirm("Plan ready", text.join("\n")) : false;
        state.planning = false;
        pi.setActiveTools(previous);
        return {
          content: [{ type: "text", text: approved ? "Approved. Build it." : "Saved to .openharness/plan.md. Stop here and wait." }],
          details: {},
          terminate: !approved,
        };
      },
    }),
  );

  // The tool only exists while planning, so it can never be called by accident.
  pi.on("before_agent_start", () => {
    if (state.planning) return;
    pi.setActiveTools(pi.getActiveTools().filter((name) => name !== "submit_plan"));
  });

  pi.registerCommand("plan", {
    description: "Explore read-only, then submit a plan for approval",
    handler: async (args) => {
      previous = pi.getActiveTools();
      state.planning = true;
      pi.setActiveTools(READ_ONLY);
      pi.sendUserMessage(`Plan this task. Read what you need, change nothing, then call submit_plan.\n\n${args}`);
    },
  });
}
