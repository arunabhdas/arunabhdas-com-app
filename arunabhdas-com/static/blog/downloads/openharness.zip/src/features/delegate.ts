import { randomBytes } from "node:crypto";
import { join } from "node:path";
import { defineTool, type ExtensionAPI, type ModelRuntime } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import { runChild } from "../child.ts";
import { HarnessState } from "../state.ts";
import { installGuard } from "./guard.ts";

const WorkerReport = Type.Object({
  summary: Type.String(),
  risks: Type.Array(Type.String()),
});

export function installDelegate(pi: ExtensionAPI, state: HarnessState, modelRuntime?: ModelRuntime) {
  pi.registerTool(
    defineTool({
      name: "delegate",
      label: "Delegate",
      description:
        "Hand one self-contained task to a worker in its own git worktree. Calls in the same turn " +
        "run in parallel. Returns a typed report and a branch for you to merge.",
      parameters: Type.Object({ task: Type.String() }),
      async execute(_id, { task }, signal, _update, ctx) {
        const id = randomBytes(3).toString("hex");
        const branch = `openharness/${id}`;
        const cwd = join(state.folder("worktrees"), id);
        const git = async (args: string[], at = ctx.cwd) => {
          const result = await pi.exec("git", args, { cwd: at, signal });
          if (result.code !== 0) throw new Error(`git ${args[0]}: ${result.stderr.trim()}`);
          return result.stdout;
        };

        await git(["worktree", "add", "-q", "-b", branch, cwd]);
        try {
          const child = new HarnessState();
          child.load(cwd);
          const report = await runChild({
            cwd,
            role: "worker",
            task: `${task}\n\nThis task is all you know. Change only what it needs.`,
            schema: WorkerReport,
            tools: ["read", "bash", "edit", "write", "grep", "find", "ls"],
            model: ctx.model,
            modelRuntime,
            extensions: [(childPi) => installGuard(childPi, child)],
          });

          await git(["add", "-A"], cwd);
          await git(["commit", "-q", "--allow-empty", "-m", `openharness: ${task.slice(0, 60)}`], cwd);
          const files = (await git(["diff", "--name-only", "HEAD~1"], cwd)).trim().split("\n").filter(Boolean);

          state.record({ kind: "delegate", branch, files: files.length });
          const result = { ...report, branch, files };
          return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }], details: result };
        } finally {
          await git(["worktree", "remove", "--force", cwd]);
        }
      },
    }),
  );
}
