import { readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { defineTool, type ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import { applyEdits, type Edit, render } from "../hashline.ts";
import type { HarnessState } from "../state.ts";

const readLines = defineTool({
  name: "read_lines",
  label: "Read lines",
  description: "Read a text file. Each line comes back as N#hash|text. Edit with those anchors.",
  parameters: Type.Object({
    path: Type.String(),
    offset: Type.Optional(Type.Number({ description: "First line, from 1" })),
    limit: Type.Optional(Type.Number()),
  }),
  async execute(_id, { path, offset, limit }, _signal, _update, ctx) {
    const text = readFileSync(resolve(ctx.cwd, path), "utf8");
    return { content: [{ type: "text", text: render(text, offset, limit) }], details: {} };
  },
});

const editLines = defineTool({
  name: "edit_lines",
  label: "Edit lines",
  description:
    "Edit a file by anchor. Replace with {from, to?, lines}, or insert with {after, lines}. " +
    'Use {after: "0"} for the top. Every anchor must be current, or nothing changes.',
  parameters: Type.Object({
    path: Type.String(),
    edits: Type.Array(
      Type.Object({
        from: Type.Optional(Type.String()),
        to: Type.Optional(Type.String()),
        after: Type.Optional(Type.String()),
        lines: Type.Array(Type.String()),
      }),
    ),
  }),
  async execute(_id, { path, edits }, _signal, _update, ctx) {
    const file = resolve(ctx.cwd, path);
    const next = applyEdits(readFileSync(file, "utf8"), edits as Edit[]);
    writeFileSync(file, next);
    return { content: [{ type: "text", text: `Edited. Current lines:\n${render(next)}` }], details: {} };
  },
});

export function installEdits(pi: ExtensionAPI, state: HarnessState) {
  pi.registerTool(readLines);
  pi.registerTool(editLines);

  // Swap the stock editor out, so the model has one way to edit and cannot mix them.
  pi.on("before_agent_start", (_event, ctx) => {
    if (state.planning) return;
    const active = new Set(pi.getActiveTools());
    const anchored = state.load(ctx.cwd).config?.hashline;
    for (const name of anchored ? ["read", "edit"] : ["read_lines", "edit_lines"]) active.delete(name);
    if (anchored) active.add("read_lines").add("edit_lines");
    pi.setActiveTools([...active]);
  });
}
