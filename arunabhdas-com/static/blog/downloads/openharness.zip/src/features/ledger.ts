import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import type { HarnessState, LedgerEntry } from "../state.ts";

export function installLedger(pi: ExtensionAPI, state: HarnessState) {
  pi.on("tool_execution_end", (event) => {
    state.record({ kind: "tool", tool: event.toolName, ok: !event.isError });
  });

  pi.on("message_end", (event) => {
    if (event.message.role !== "assistant") return;
    const { totalTokens, cost } = event.message.usage;
    state.record({ kind: "turn", tokens: totalTokens, cost: cost.total });
  });

  pi.registerCommand("report", {
    description: "Summarize this run",
    handler: async (_args, ctx) => ctx.ui.notify(JSON.stringify(summarize(state.entries), null, 2), "info"),
  });
}

export function summarize(entries: LedgerEntry[]) {
  const count = (kind: string, test: (e: LedgerEntry) => boolean = () => true) =>
    entries.filter((e) => e.kind === kind && test(e)).length;
  const turns = entries.filter((e) => e.kind === "turn");
  const last = entries.findLast((e) => e.kind === "status");

  return {
    status: (last?.status as string) ?? "unchanged",
    turns: turns.length,
    tools: count("tool"),
    toolErrors: count("tool", (e) => e.ok === false),
    blocked: count("blocked"),
    tampered: count("tamper"),
    rules: count("rule"),
    verifyFailures: count("verify", (e) => e.ok === false),
    reviews: count("review"),
    tokens: turns.reduce((sum, e) => sum + Number(e.tokens), 0),
    cost: turns.reduce((sum, e) => sum + Number(e.cost), 0),
  };
}
