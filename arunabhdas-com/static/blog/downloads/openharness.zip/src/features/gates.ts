import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import type { ExtensionAPI, ExtensionContext, ModelRuntime } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import { runChild } from "../child.ts";
import type { Config } from "../config.ts";
import { isProtected } from "../policy.ts";
import type { HarnessState } from "../state.ts";

const SNAPSHOT = "git status --porcelain; git diff HEAD; git ls-files -o --exclude-standard | xargs shasum 2>/dev/null";

export const Review = Type.Object({
  verdict: Type.Union([Type.Literal("ship"), Type.Literal("fix")]),
  findings: Type.Array(
    Type.Object({
      priority: Type.Union(["P0", "P1", "P2", "P3"].map((p) => Type.Literal(p))),
      file: Type.String(),
      issue: Type.String(),
    }),
  ),
});

export function installGates(pi: ExtensionAPI, state: HarnessState, modelRuntime?: ModelRuntime) {
  let baseline: string | undefined;
  let attempts = 0;
  const originals = new Map<string, string>();

  const sh = (command: string, ctx: ExtensionContext) =>
    pi.exec("bash", ["-c", command], { cwd: ctx.cwd, signal: ctx.signal, timeout: 600_000 });

  const snapshot = async (ctx: ExtensionContext) => (await sh(SNAPSHOT, ctx)).stdout;

  const push = (text: string) => ({ type: "custom_message" as const, customType: "openharness-gate", content: text, display: true });

  /** Remembers frozen files as they were when the task began. */
  async function freeze(config: Config, ctx: ExtensionContext) {
    originals.clear();
    for (const file of (await sh("git ls-files", ctx)).stdout.split("\n")) {
      if (file && isProtected(file, config.frozen)) {
        originals.set(file, readFileSync(join(ctx.cwd, file), "utf8"));
      }
    }
  }

  /** Puts frozen files back, whichever tool changed them. Bash cannot get around this. */
  function thaw(ctx: ExtensionContext) {
    const changed: string[] = [];
    for (const [file, text] of originals) {
      const path = join(ctx.cwd, file);
      if (existsSync(path) && readFileSync(path, "utf8") === text) continue;
      writeFileSync(path, text);
      changed.push(file);
    }
    return changed;
  }

  async function verify(config: Config, ctx: ExtensionContext) {
    for (const command of config.verify) {
      const result = await sh(command, ctx);
      state.record({ kind: "verify", command, ok: result.code === 0 });
      if (result.code !== 0) {
        const tail = `${result.stdout}\n${result.stderr}`.trim().slice(-3000);
        return `\`${command}\` failed with exit code ${result.code}:\n\n${tail}`;
      }
    }
    return undefined;
  }

  async function review(config: Config, ctx: ExtensionContext) {
    if (!config.review.enabled) return undefined;
    const diff = (await sh("git diff HEAD; git ls-files -o --exclude-standard", ctx)).stdout;
    const [provider, ...id] = config.review.model?.split("/") ?? [];
    const model = provider ? ctx.modelRegistry.find(provider, id.join("/")) : ctx.model;
    if (!model) throw new Error(`Unknown review model: ${config.review.model}`);

    const result = await runChild({
      cwd: ctx.cwd,
      role: "reviewer",
      task: `You did not write this change. Review it for bugs, not style. Read files if you need more.\n\n${diff}`,
      schema: Review,
      tools: ["read", "grep", "find", "ls"],
      model,
      modelRuntime,
    });

    state.record({ kind: "review", verdict: result.verdict, findings: result.findings.length });
    const blocking = result.findings.filter((f) => (config.review.blockOn as string[]).includes(f.priority));
    if (!blocking.length) return undefined;
    return `Review found:\n${blocking.map((f) => `- ${f.priority} ${f.file}: ${f.issue}`).join("\n")}`;
  }

  pi.on("input", async (_event, ctx) => {
    attempts = 0;
    baseline = await snapshot(ctx);
    const { config } = state.load(ctx.cwd);
    if (config) await freeze(config, ctx);
  });

  // The run wants to finish. This is the only door, and the gates hold it shut.
  pi.on("agent_before_settle", async (event, ctx) => {
    const { config, error } = state.load(ctx.cwd);
    if (event.outcome !== "completed" || state.planning) return undefined;
    if (!config) {
      state.status = "failed";
      state.record({ kind: "status", status: "failed", reason: error });
      return { entries: [...event.entries, push(`OpenHarness is blocking writes: ${error}`)] };
    }

    const thawed = thaw(ctx);
    if (thawed.length) state.record({ kind: "tamper", files: thawed });

    const unchanged = !thawed.length && (await snapshot(ctx)) === baseline;
    if (unchanged && !state.expectChange) {
      state.status = "unchanged";
      return undefined;
    }

    let problem: string | undefined;
    try {
      if (thawed.length) {
        problem = `You changed ${thawed.join(", ")}, which is frozen. It has been restored. Find the code it tests and fix that instead.`;
      } else if (unchanged) {
        problem = "You have not changed anything yet. Find the code under test, read it, and fix it there.";
      } else {
        problem = (await verify(config, ctx)) ?? (await review(config, ctx));
      }
    } catch (failure) {
      // A gate that cannot run has not passed. Never turn that into a green result.
      state.status = "failed";
      state.record({ kind: "status", status: "failed", reason: String(failure) });
      return { entries: [...event.entries, push(`OpenHarness could not finish its checks: ${failure}`)] };
    }

    if (!problem) {
      state.status = "passed";
      state.record({ kind: "status", status: "passed" });
      return undefined;
    }

    attempts += 1;
    if (attempts > config.maxRetries) {
      state.status = "failed";
      state.record({ kind: "status", status: "failed", reason: "out of retries" });
      return { entries: [...event.entries, push(`Giving up after ${config.maxRetries} retries.\n\n${problem}`)] };
    }
    return { entries: [...event.entries, push(`Not done yet. ${problem}`)], continue: true };
  });
}
