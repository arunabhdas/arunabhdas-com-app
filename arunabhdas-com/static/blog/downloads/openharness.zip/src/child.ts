import { type Model } from "@earendil-works/pi-ai";
import {
  createAgentSession,
  DefaultResourceLoader,
  defineTool,
  getAgentDir,
  type InlineExtension,
  type ModelRuntime,
  SessionManager,
  SettingsManager,
} from "@earendil-works/pi-coding-agent";
import type { Static, TSchema } from "typebox";

export type ChildOptions<T extends TSchema> = {
  cwd: string;
  role: string;
  task: string;
  schema: T;
  tools: string[];
  model?: Model<any>;
  modelRuntime?: ModelRuntime;
  extensions?: InlineExtension[];
};

/** Runs a fresh agent with its own context. The only way out is a typed report. */
export async function runChild<T extends TSchema>(options: ChildOptions<T>) {
  let result: Static<T> | undefined;

  const report = defineTool({
    name: "report",
    label: "Report",
    description: "Finish by reporting your result. This is the only output anyone will read.",
    parameters: options.schema,
    async execute(_id, params) {
      result = params as Static<T>;
      return { content: [{ type: "text", text: "Reported." }], details: {}, terminate: true };
    },
  });

  const agentDir = getAgentDir();
  const resourceLoader = new DefaultResourceLoader({
    cwd: options.cwd,
    agentDir,
    noExtensions: true,
    noSkills: true,
    noPromptTemplates: true,
    noThemes: true,
    extensionFactories: options.extensions ?? [],
    appendSystemPrompt: [`You are the ${options.role}. When finished, call report. Do not reply in prose.`],
  });
  await resourceLoader.reload();

  const { session } = await createAgentSession({
    cwd: options.cwd,
    agentDir,
    model: options.model,
    modelRuntime: options.modelRuntime,
    resourceLoader,
    tools: [...options.tools, "report"],
    customTools: [report],
    sessionManager: SessionManager.inMemory(options.cwd),
    settingsManager: SettingsManager.inMemory({ compaction: { enabled: false } }),
  });

  try {
    await session.prompt(options.task);
  } finally {
    session.dispose();
  }
  if (result === undefined) throw new Error(`The ${options.role} finished without a report.`);
  return result;
}
