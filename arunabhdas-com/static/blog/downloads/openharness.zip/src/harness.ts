import { fileURLToPath } from "node:url";
import type { Model } from "@earendil-works/pi-ai";
import {
  createAgentSession,
  DefaultResourceLoader,
  getAgentDir,
  type ModelRuntime,
  SessionManager,
  SettingsManager,
} from "@earendil-works/pi-coding-agent";
import { summarize } from "./features/ledger.ts";
import { install } from "./install.ts";
import { HarnessState } from "./state.ts";

const root = (path: string) => fileURLToPath(new URL(`../${path}`, import.meta.url));

export type HarnessOptions = { cwd: string; model?: Model<any>; modelRuntime?: ModelRuntime };

/** Pi, with OpenHarness installed, as a plain function. The CLI and the tests both use this. */
export async function createHarness({ cwd, model, modelRuntime }: HarnessOptions) {
  const state = new HarnessState();
  state.load(cwd);

  const agentDir = getAgentDir();
  const resourceLoader = new DefaultResourceLoader({
    cwd,
    agentDir,
    noExtensions: true,
    additionalSkillPaths: [root("skills")],
    additionalPromptTemplatePaths: [root("prompts")],
    extensionFactories: [(pi) => void install(pi, { state, modelRuntime })],
  });
  await resourceLoader.reload();

  const { session } = await createAgentSession({
    cwd,
    agentDir,
    model,
    modelRuntime,
    resourceLoader,
    sessionManager: SessionManager.inMemory(cwd),
    settingsManager: SettingsManager.inMemory({ compaction: { enabled: true } }),
  });

  return {
    session,
    state,
    /** A task is meant to change something. Pass expectChange: false for a question. */
    async run(task: string, { expectChange = true } = {}) {
      state.expectChange = expectChange;
      await session.prompt(task);
      await session.waitForIdle();
      return summarize(state.entries);
    },
  };
}
