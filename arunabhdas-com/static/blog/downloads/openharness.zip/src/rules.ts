export type Rule = { name: string; pattern: string; message: string };

type Block = { type: string; text?: string; arguments?: unknown; partialJson?: string };

/** Everything the model has produced so far, tool arguments included. */
export function produced(content: Block[]) {
  return content
    .map((block) => {
      if (block.type === "text") return block.text ?? "";
      if (block.type === "toolCall") return block.partialJson ?? JSON.stringify(block.arguments ?? {});
      return "";
    })
    .join("\n");
}

/** Rules that already fired are skipped, so one rule can never cause an endless retry. */
export function firstHit(text: string, rules: Rule[], fired: Set<string>) {
  return rules.find((rule) => !fired.has(rule.name) && new RegExp(rule.pattern).test(text));
}
