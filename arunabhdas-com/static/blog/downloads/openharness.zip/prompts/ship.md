---
description: Take a task from plan to a reviewed change
argument-hint: "<task>"
---
Use the engineering-loop skill. Task: $@

Make the change, get the checks green, and finish with a short summary of what changed and why.
