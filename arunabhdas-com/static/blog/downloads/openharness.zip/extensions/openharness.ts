import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { install } from "../src/install.ts";

export default function openharness(pi: ExtensionAPI) {
  install(pi);
}
