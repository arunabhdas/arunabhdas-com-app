import assert from "node:assert/strict";
import { existsSync, readdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { test } from "node:test";
import { setTimeout } from "node:timers/promises";
import { fauxAssistantMessage as say, fauxToolCall as call } from "@earendil-works/pi-ai";
import { lineHash } from "../src/hashline.ts";
import { scripted, sandbox } from "./helpers.ts";

const BUG = "export const add = (a, b) => a - b;";
const STILL_WRONG = "export const add = (a, b) => a * b + 1;";
const FIXED = "export const add = (a, b) => a + b;";
const edit = (from: string, to: string) =>
  say(call("edit_lines", { path: "math.js", edits: [{ from: `1#${lineHash(from)}`, lines: [to] }] }));
const ship = say(call("report", { verdict: "ship", findings: [] }));
const text = (path: string, cwd: string) => readFileSync(join(cwd, path), "utf8");

test("the verify gate refuses to finish until the checks pass", async () => {
  const { cwd } = sandbox();
  const h = await scripted(cwd);
  h.faux.setResponses([edit(BUG, STILL_WRONG), say("Done!"), edit(STILL_WRONG, FIXED), say("Done now."), ship, say("Summary.")]);

  const result = await h.run("fix add");

  assert.equal(result.status, "passed");
  assert.equal(result.verifyFailures, 1);
  assert.equal(result.reviews, 1);
  assert.equal(text("math.js", cwd), `${FIXED}\n`);
  h.session.dispose();
});

test("a model that never fixes it runs out of retries and fails", async () => {
  const { cwd } = sandbox({ maxRetries: 1 });
  const h = await scripted(cwd);
  h.faux.setResponses([edit(BUG, STILL_WRONG), say("Done!"), say("Still done!")]);

  const result = await h.run("fix add");

  assert.equal(result.status, "failed");
  assert.equal(result.verifyFailures, 2);
  h.session.dispose();
});

test("the failing output reaches the model", async () => {
  const { cwd } = sandbox();
  const h = await scripted(cwd);
  let seen = "";
  h.faux.setResponses([
    edit(BUG, STILL_WRONG),
    say("Done!"),
    (context) => {
      seen = JSON.stringify(context.messages.at(-1));
      return edit(STILL_WRONG, FIXED);
    },
    say("Fixed."),
    ship,
    say("Summary."),
  ]);

  await h.run("fix add");

  assert.match(seen, /add\(2, 2\) should be 4/);
  h.session.dispose();
});

test("review can send the work back", async () => {
  const { cwd } = sandbox();
  const h = await scripted(cwd);
  const finding = { priority: "P1", file: "math.js", issue: "No test for negatives." };
  h.faux.setResponses([
    edit(BUG, FIXED),
    say("Done."),
    say(call("report", { verdict: "fix", findings: [finding] })),
    say(call("write", { path: "negatives.js", content: "// covered\n" })),
    say("Added."),
    ship,
    say("Summary."),
  ]);

  const result = await h.run("fix add");

  assert.equal(result.status, "passed");
  assert.equal(result.reviews, 2);
  h.session.dispose();
});

test("a reviewer that never reports fails the run, not passes it", async () => {
  const { cwd } = sandbox();
  const h = await scripted(cwd);
  h.faux.setResponses([edit(BUG, FIXED), say("Done."), say("Looks fine to me, no report.")]);

  const result = await h.run("fix add");

  assert.equal(result.status, "failed");
  h.session.dispose();
});

test("a typo in the review model fails, it does not fall back", async () => {
  const { cwd } = sandbox({ review: { model: "nobody/nothing" } });
  const h = await scripted(cwd);
  h.faux.setResponses([edit(BUG, FIXED), say("Done.")]);

  const result = await h.run("fix add");

  assert.equal(result.status, "failed");
  h.session.dispose();
});

test("a frozen check cannot be edited, but it can be read", async () => {
  const { cwd } = sandbox({ frozen: ["check.js"] });
  const h = await scripted(cwd);
  h.faux.setResponses([
    say(call("read_lines", { path: "check.js" })),
    say(call("write", { path: "check.js", content: "// gone\n" })),
    say("OK."),
  ]);

  const result = await h.run("fix add", { expectChange: false });

  assert.equal(result.blocked, 1);
  assert.equal(result.toolErrors, 1, "only the write fails");
  assert.match(text("check.js", cwd), /should be 4/);
  h.session.dispose();
});

test("rewriting a frozen check through bash is undone and sent back", async () => {
  const { cwd } = sandbox({ mode: "yolo", frozen: ["check.js"] });
  const h = await scripted(cwd);
  let told = "";
  h.faux.setResponses([
    say(call("bash", { command: "echo 'console.log(1)' > check.js" })),
    say("All green!"),
    (context) => {
      told = JSON.stringify(context.messages.at(-1));
      return edit(BUG, FIXED);
    },
    say("Fixed for real."),
    ship,
    say("Summary."),
  ]);

  const result = await h.run("fix add");

  assert.match(told, /which is frozen/);
  assert.match(text("check.js", cwd), /should be 4/);
  assert.equal(result.tampered, 1);
  assert.equal(result.status, "passed");
  h.session.dispose();
});

test("without frozen, a rewritten check passes: the hole this closes", async () => {
  const { cwd } = sandbox({ mode: "yolo", review: { enabled: false } });
  const h = await scripted(cwd);
  h.faux.setResponses([say(call("bash", { command: "echo 'console.log(1)' > check.js" })), say("All green!")]);

  const result = await h.run("fix add");

  assert.equal(result.status, "passed");
  assert.equal(text("math.js", cwd), `${BUG}\n`);
  h.session.dispose();
});

test("a task that changes nothing is sent back, then fails", async () => {
  const { cwd } = sandbox({ maxRetries: 1 });
  const h = await scripted(cwd);
  h.faux.setResponses([say("Please make the change yourself."), say("I still won't."), say("No.")]);

  const result = await h.run("fix add");

  assert.equal(result.status, "failed");
  assert.equal(result.turns, 2);
  h.session.dispose();
});

test("a question that changes nothing skips the gates", async () => {
  const { cwd } = sandbox();
  const h = await scripted(cwd);
  h.faux.setResponses([say("add subtracts. That looks like a bug.")]);

  const result = await h.run("what does add do?", { expectChange: false });

  assert.equal(result.status, "unchanged");
  assert.equal(result.verifyFailures, 0);
  h.session.dispose();
});

test("the guard blocks a protected write and the run carries on", async () => {
  const { cwd } = sandbox();
  const h = await scripted(cwd);
  h.faux.setResponses([say(call("write", { path: ".env", content: "KEY=1" })), say("Understood.")]);

  const result = await h.run("save the key", { expectChange: false });

  assert.equal(result.blocked, 1);
  assert.equal(existsSync(join(cwd, ".env")), false);
  h.session.dispose();
});

test("with no UI, a call that needs approval is refused", async () => {
  const { cwd } = sandbox();
  const h = await scripted(cwd);
  h.faux.setResponses([say(call("bash", { command: "touch made-by-bash" })), say("OK.")]);

  const result = await h.run("run it", { expectChange: false });

  assert.equal(result.blocked, 1);
  assert.equal(existsSync(join(cwd, "made-by-bash")), false);
  h.session.dispose();
});

test("a broken harness.json fails closed", async () => {
  const { cwd } = sandbox();
  writeFileSync(join(cwd, "harness.json"), "{ not json");
  const h = await scripted(cwd);
  h.faux.setResponses([say(call("write", { path: "a.txt", content: "x" })), say("OK.")]);

  await h.run("write a file", { expectChange: false });

  assert.equal(existsSync(join(cwd, "a.txt")), false);
  assert.equal(h.state.status, "failed");
  h.session.dispose();
});

test("a stale edit is rejected and the file is untouched", async () => {
  const { cwd } = sandbox();
  const h = await scripted(cwd);
  h.faux.setResponses([edit("this is not the file", FIXED), say("Hm.")]);

  const result = await h.run("fix add", { expectChange: false });

  assert.equal(result.toolErrors, 1);
  assert.equal(text("math.js", cwd), `${BUG}\n`);
  h.session.dispose();
});

test("the stock editor is swapped for the anchored one", async () => {
  const { cwd } = sandbox();
  const h = await scripted(cwd);
  h.faux.setResponses([say("Hello.")]);

  await h.run("hi", { expectChange: false });

  const tools = h.session.getActiveToolNames();
  assert.ok(tools.includes("edit_lines") && tools.includes("read_lines"));
  assert.ok(!tools.includes("edit") && !tools.includes("read"));
  h.session.dispose();
});

test("a stream rule stops the model, drops the attempt, and retries", async () => {
  const rule = { name: "no-log", pattern: "console\\.log", message: "Use the logger." };
  const { cwd } = sandbox({ rules: [rule] });
  const h = await scripted(cwd, 400);
  let retry = "";
  h.faux.setResponses([
    say(call("write", { path: "bad.js", content: `console.log("hi"); // ${"padding ".repeat(60)}` })),
    (context) => {
      retry = JSON.stringify(context.messages);
      return say("I will use the logger.");
    },
  ]);

  const result = await h.run("add logging");

  assert.equal(result.rules, 1);
  assert.equal(existsSync(join(cwd, "bad.js")), false, "the tool call must never run");
  assert.match(retry, /Use the logger/);
  assert.doesNotMatch(retry, /padding/, "the bad attempt must be gone");
  h.session.dispose();
});

test("/plan is read-only, and an unapproved plan stops", async () => {
  const { cwd } = sandbox();
  const h = await scripted(cwd);
  let tools: string[] = [];
  h.faux.setResponses([
    () => {
      tools = h.session.getActiveToolNames();
      return say(call("submit_plan", { goal: "Fix add", steps: ["Change - to +"], verification: "node check.js" }));
    },
  ]);

  await h.session.prompt("/plan fix add");
  while (h.faux.getPendingResponseCount() > 0) await setTimeout(5); // commands queue their run
  await h.session.waitForIdle();

  assert.deepEqual(tools.sort(), ["find", "grep", "ls", "read", "submit_plan"]);
  assert.match(text(".openharness/plan.md", cwd), /Fix add/);
  assert.equal(text("math.js", cwd), `${BUG}\n`);
  h.session.dispose();
});

test("parallel workers get isolated worktrees and typed reports", async () => {
  const { cwd, git } = sandbox();
  const h = await scripted(cwd);
  const worker = (name: string) => [
    say(call("write", { path: `${name}.txt`, content: name })),
    say(call("report", { summary: `Wrote ${name}`, risks: [] })),
  ];
  h.faux.setResponses([
    say([call("delegate", { task: "write a" }), call("delegate", { task: "write b" })]),
    ...worker("a"),
    ...worker("b"),
    say("Both done."),
  ]);

  await h.run("do two things", { expectChange: false });

  const branches = git("branch", "--list", "openharness/*").trim().split("\n");
  assert.equal(branches.length, 2);
  assert.equal(git("worktree", "list").trim().split("\n").length, 1, "worktrees are cleaned up");
  assert.equal(existsSync(join(cwd, "a.txt")), false, "the main tree stays clean");
  h.session.dispose();
});

test("a worker cannot reach protected files either", async () => {
  const { cwd, git } = sandbox();
  const h = await scripted(cwd);
  h.faux.setResponses([
    say(call("delegate", { task: "save the key" })),
    say(call("write", { path: ".env", content: "KEY=1" })),
    say(call("report", { summary: "Blocked.", risks: ["Could not write .env"] })),
    say("OK."),
  ]);

  await h.run("delegate it", { expectChange: false });

  const branch = git("branch", "--list", "openharness/*").trim();
  assert.equal(git("show", "--stat", "--format=", branch).trim(), "");
  h.session.dispose();
});

test("a worker that fails still cleans up its worktree", async () => {
  const { cwd, git } = sandbox();
  const h = await scripted(cwd);
  h.faux.setResponses([say(call("delegate", { task: "do it" })), say("I will not report."), say("It failed.")]);

  const result = await h.run("delegate it", { expectChange: false });

  assert.equal(result.toolErrors, 1);
  assert.equal(git("worktree", "list").trim().split("\n").length, 1);
  h.session.dispose();
});

test("the /ship prompt and the skill ship with the package", async () => {
  const { cwd } = sandbox();
  const h = await scripted(cwd);
  let seen = "";
  h.faux.setResponses([
    (context) => {
      seen = JSON.stringify(context.messages);
      return say("Nothing to do.");
    },
  ]);

  await h.run("/ship fix add", { expectChange: false });

  assert.match(seen, /Use the engineering-loop skill\. Task: fix add/);
  assert.match(seen, /engineering-loop/);
  h.session.dispose();
});

test("every run leaves a ledger", async () => {
  const { cwd } = sandbox();
  const h = await scripted(cwd);
  h.faux.setResponses([edit(BUG, FIXED), say("Done."), ship, say("Summary.")]);

  const result = await h.run("fix add");

  assert.equal(result.status, "passed");
  assert.ok(result.turns >= 2 && result.tools >= 1);
  assert.ok(readdirSync(join(cwd, ".openharness/runs")).length === 1);
  h.session.dispose();
});
