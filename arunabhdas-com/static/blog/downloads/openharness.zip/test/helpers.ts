import { execFileSync } from "node:child_process";
import { mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { registerFauxProvider } from "@earendil-works/pi-ai/compat";
import { ModelRuntime } from "@earendil-works/pi-coding-agent";
import { createHarness } from "../src/harness.ts";

const BUGGY = "export const add = (a, b) => a - b;\n";
const TEST = 'import { add } from "./math.js";\nif (add(2, 2) !== 4) throw new Error("add(2, 2) should be 4");\n';

/** A tiny git repo with one bug and one failing check. */
export function sandbox(config: object = {}) {
  const cwd = mkdtempSync(join(tmpdir(), "openharness-"));
  writeFileSync(join(cwd, "package.json"), '{ "type": "module" }\n');
  writeFileSync(join(cwd, "math.js"), BUGGY);
  writeFileSync(join(cwd, "check.js"), TEST);
  writeFileSync(join(cwd, "harness.json"), JSON.stringify({ verify: ["node check.js"], ...config }));
  const git = (...args: string[]) => execFileSync("git", args, { cwd, stdio: "pipe" }).toString();
  git("init", "-q");
  git("config", "user.email", "test@example.com");
  git("config", "user.name", "Test");
  git("add", "-A");
  git("commit", "-q", "-m", "start");
  return { cwd, git };
}

/** Real Pi, real tools, real gates. Only the model is scripted. */
export async function scripted(cwd: string, tokensPerSecond = 0) {
  const faux = registerFauxProvider({ tokensPerSecond });
  const model = faux.getModel();
  const modelRuntime = await ModelRuntime.create({ modelsPath: null, allowModelNetwork: false });
  modelRuntime.registerProvider(model.provider, {
    baseUrl: model.baseUrl,
    api: model.api,
    apiKey: "scripted",
    models: [{ ...model }],
  });
  const harness = await createHarness({ cwd, model, modelRuntime });
  return { ...harness, faux };
}
