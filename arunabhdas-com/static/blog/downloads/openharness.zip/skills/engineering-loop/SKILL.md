---
name: engineering-loop
description: How to work inside OpenHarness. Use for any change to this codebase that will go through verification and review.
---

# The engineering loop

1. Read before you write. Use `read_lines`, because its anchors are how you edit.
2. Make the smallest change that solves the task.
3. Run the project's checks yourself before you say you are done.
4. Stop when you are done. The harness runs `verify` and review when you finish, and it will send you back with the reason if either fails.
5. If you are sent back, fix the cause. Never edit a test only to make it pass.
6. Split work that has independent parts with `delegate`, then merge each branch it returns.
