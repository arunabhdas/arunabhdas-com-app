import ActionEngine
import Foundation

let usage = """
usage: act plan "<request>"   Build a plan and print its hash
       act run <hash>         Run a plan you have read
       act replay <hash>      Rebuild a plan from the audit log, without a model
       act eval <cases.jsonl> Score the engine against a test set
"""

var arguments = Array(CommandLine.arguments.dropFirst())
let environment = ProcessInfo.processInfo.environment

@MainActor func option(_ name: String) -> String? {
    guard let index = arguments.firstIndex(of: name), index + 1 < arguments.count else { return nil }
    defer { arguments.removeSubrange(index...(index + 1)) }
    return arguments[index + 1]
}

func fail(_ message: Any) -> Never {
    print("stopped: \(message)")
    exit(1)
}

let now = option("--now").flatMap { try? Date($0, strategy: .iso8601) } ?? Date()
let timeZone = environment["ACT_TZ"].flatMap(TimeZone.init(identifier:)) ?? .current
let workspace = try Workspace(root: URL(filePath: environment["ACT_HOME"] ?? ".act"))

func proposer() -> (any Proposer)? {
    if let path = environment["ACT_MODEL"] { return LlamaProposer(modelPath: path) }
    #if canImport(FoundationModels)
    if AppleProposer.isAvailable { return AppleProposer() }
    #endif
    return nil
}

func describe(_ action: Action) -> String {
    let data = (try? canonicalJSON(action)) ?? Data()
    return String(decoding: data, as: UTF8.self)
}

@MainActor func load(_ hash: String) throws -> Routed? {
    try workspace.lines(of: workspace.audit).reversed()
        .lazy.compactMap { try? decodeCanonical(Routed.self, from: Data($0.utf8)) }
        .first { $0.hash == hash }
}

guard let command = arguments.first, arguments.count == 2 else {
    print(usage)
    exit(2)
}
let input = arguments[1]

do {
    switch command {
    case "plan":
        let engine = Engine(now: now, timeZone: timeZone, proposer: proposer())
        let routed = try await engine.plan(input)
        try canonicalJSON(routed.plan).write(to: workspace.plan(routed.hash))
        try workspace.append(try canonicalJSON(routed), to: workspace.audit)
        print("route   \(routed.route)")
        print("tokens  \(routed.localTokens) local, \(routed.cloudTokens) cloud")
        print("time    \(String(format: "%.2f", routed.milliseconds)) ms")
        for step in routed.plan.steps { print("\(step.id)      \(describe(step.action))") }
        print("hash    \(routed.hash)")

    case "run":
        let data = try Data(contentsOf: workspace.plan(input))
        let plan = try decodeCanonical(Plan.self, from: data)
        guard try fingerprint(plan) == input else { fail("this plan changed after you read it.") }
        for entry in try Executor(workspace: workspace, now: now).run(plan) {
            print("\(entry.step)  \(entry.status)  \(entry.detail)")
        }

    case "replay":
        guard let record = try load(input) else { fail("no record of \(input).") }
        let plan = try Engine.replay(record, timeZone: timeZone)
        print(try fingerprint(plan) == input ? "identical  \(input)" : "different  \(input)")

    case "eval":
        let report = try await Evaluation.run(
            file: URL(filePath: input), engine: Engine(now: now, timeZone: timeZone, proposer: proposer()))
        print(report)

    default:
        print(usage)
        exit(2)
    }
} catch {
    fail(error)
}
