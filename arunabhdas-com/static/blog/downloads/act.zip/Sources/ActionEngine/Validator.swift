import Foundation

public enum PlanError: Error, Equatable, CustomStringConvertible {
    case empty
    case tooManySteps(Int)
    case duplicateStep(String)
    case unknownDependency(step: String, needs: String)
    case cycle
    case badField(step: String, reason: String)

    public var description: String {
        switch self {
        case .empty: "The plan has no steps."
        case .tooManySteps(let n): "The plan has \(n) steps. The limit is \(Validator.maxSteps)."
        case .duplicateStep(let id): "Two steps share the id \(id)."
        case .unknownDependency(let step, let needs): "Step \(step) waits for \(needs), which does not exist."
        case .cycle: "The steps wait for each other in a loop."
        case .badField(let step, let reason): "Step \(step): \(reason)"
        }
    }
}

public struct Validator: Sendable {
    public static let maxSteps = 8
    public let now: Date

    public init(now: Date) { self.now = now }

    /// Returns the steps in the order they must run, or the reason they cannot.
    public func check(_ plan: Plan) throws(PlanError) -> [Step] {
        guard !plan.steps.isEmpty else { throw .empty }
        guard plan.steps.count <= Self.maxSteps else { throw .tooManySteps(plan.steps.count) }

        var ids = Set<String>()
        for step in plan.steps {
            guard ids.insert(step.id).inserted else { throw .duplicateStep(step.id) }
        }
        for step in plan.steps {
            try checkFields(step)
            for needed in step.after where !ids.contains(needed) {
                throw .unknownDependency(step: step.id, needs: needed)
            }
        }
        return try ordered(plan.steps)
    }

    func checkFields(_ step: Step) throws(PlanError) {
        func bad(_ reason: String) -> PlanError { .badField(step: step.id, reason: reason) }
        let horizon = now.addingTimeInterval(2 * 365 * 86_400)

        switch step.action {
        case .addTask(let title, let due):
            try checkTitle(title, step)
            if let due, due < now || due > horizon { throw bad("the due date is not in the next two years.") }
        case .scheduleEvent(let title, let start, let minutes):
            try checkTitle(title, step)
            if start < now || start > horizon { throw bad("the start is not in the next two years.") }
            if !(5...480).contains(minutes) { throw bad("an event lasts 5 to 480 minutes.") }
        case .saveNote(let title, let body):
            try checkTitle(title, step)
            if body.isEmpty || body.count > 4_000 { throw bad("a note body has 1 to 4,000 characters.") }
        case .extractTasks(let note):
            try checkTitle(note, step)
        }
    }

    func checkTitle(_ title: String, _ step: Step) throws(PlanError) {
        if title.trimmingCharacters(in: .whitespaces).isEmpty || title.count > 120 {
            throw .badField(step: step.id, reason: "a title has 1 to 120 characters.")
        }
        if title.contains(where: \.isNewline) {
            throw .badField(step: step.id, reason: "a title is a single line.")
        }
    }

    /// Kahn's algorithm. Ties keep plan order, so the result never varies.
    func ordered(_ steps: [Step]) throws(PlanError) -> [Step] {
        var done = Set<String>()
        var result: [Step] = []
        while result.count < steps.count {
            guard let next = steps.first(where: {
                !done.contains($0.id) && $0.after.allSatisfy(done.contains)
            }) else { throw .cycle }
            done.insert(next.id)
            result.append(next)
        }
        return result
    }
}
