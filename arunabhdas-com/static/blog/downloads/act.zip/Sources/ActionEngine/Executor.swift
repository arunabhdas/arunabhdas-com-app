import Foundation

public struct Entry: Codable, Equatable, Sendable {
    public var key: String
    public var step: String
    public var status: String
    public var detail: String
}

public struct Executor: Sendable {
    public let workspace: Workspace
    public let now: Date
    /// Tests use this to crash after a side effect, before it is recorded.
    public var crashAfter: String?

    public init(workspace: Workspace, now: Date, crashAfter: String? = nil) {
        self.workspace = workspace
        self.now = now
        self.crashAfter = crashAfter
    }

    public struct Crash: Error {}

    /// Runs a plan in dependency order. Finished steps are never run again.
    @discardableResult
    public func run(_ plan: Plan) throws -> [Entry] {
        let order = try Validator(now: now).check(plan)
        let handlers = Handlers(workspace: workspace)
        let finished = Set(journal().filter { $0.status == "done" }.map(\.key))
        var results: [Entry] = []

        for step in order {
            let key = try fingerprint(step)
            if finished.contains(key) {
                results.append(Entry(key: key, step: step.id, status: "skipped", detail: "already done"))
                continue
            }
            try record(Entry(key: key, step: step.id, status: "started", detail: ""))
            do {
                let detail = try handlers.perform(step.action, key: key)
                if crashAfter == step.id { throw Crash() }
                let entry = Entry(key: key, step: step.id, status: "done", detail: detail)
                try record(entry)
                results.append(entry)
            } catch is Crash {
                throw Crash()
            } catch {
                let reason = String(describing: error)
                try record(Entry(key: key, step: step.id, status: "failed", detail: reason))
                throw EngineError.rejected(reason)
            }
        }
        return results
    }

    func record(_ entry: Entry) throws {
        try workspace.append(try canonicalJSON(entry), to: workspace.journal)
    }

    public func journal() -> [Entry] {
        workspace.lines(of: workspace.journal).compactMap {
            try? decodeCanonical(Entry.self, from: Data($0.utf8))
        }
    }
}
