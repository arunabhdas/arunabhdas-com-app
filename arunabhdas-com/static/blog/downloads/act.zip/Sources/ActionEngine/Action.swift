import Foundation

/// Everything the engine can ever do. There is no `case other`.
public enum Action: Codable, Equatable, Sendable {
    case addTask(title: String, due: Date?)
    case scheduleEvent(title: String, start: Date, minutes: Int)
    case saveNote(title: String, body: String)
    case extractTasks(note: String)
}

public struct Step: Codable, Equatable, Sendable {
    public var id: String
    public var action: Action
    public var after: [String]

    public init(id: String, action: Action, after: [String] = []) {
        self.id = id
        self.action = action
        self.after = after
    }
}

public struct Plan: Codable, Equatable, Sendable {
    public var steps: [Step]

    public init(steps: [Step]) { self.steps = steps }
}
