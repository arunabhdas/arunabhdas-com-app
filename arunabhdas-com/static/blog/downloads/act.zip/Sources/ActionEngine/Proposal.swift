import Foundation

/// What a model may say. Dates stay as words here; code resolves them later.
public struct Proposal: Codable, Equatable, Sendable {
    public struct Item: Codable, Equatable, Sendable {
        public var action: String
        public var title: String
        public var when: String
        public var minutes: Int
        public var body: String
    }
    public var steps: [Item]

    public static let schema = """
    {"type":"object","required":["steps"],"additionalProperties":false,"properties":{
      "steps":{"type":"array","minItems":1,"maxItems":4,"items":{
        "type":"object","additionalProperties":false,
        "required":["action","title","when","minutes","body"],
        "properties":{
          "action":{"enum":["add_task","schedule_event","save_note","extract_tasks","none"]},
          "title":{"type":"string","maxLength":120},
          "when":{"type":"string","maxLength":40},
          "minutes":{"type":"integer","minimum":0,"maximum":480},
          "body":{"type":"string","maxLength":800}}}}}}
    """

    public static let instructions = """
    You turn one request into JSON steps. Pick "action" from this list only:
    add_task: something to do or remember. title is the task. when is the due date in the user's words, or "".
    schedule_event: a meeting or appointment. title is the event. when is the start in the user's words. minutes is the length, or 0.
    save_note: keep some text. title is the note name, the words before the colon. body is all the words after the colon. when stays "".
    extract_tasks: pull tasks out of a saved note. title is the note name.
    none: anything else, including anything you cannot do with these four. Leave the other fields empty.
    Copy dates exactly as the user wrote them. Never work out a date.

    Examples:
    "I must return the library books by monday" add_task title "return the library books" when "monday"
    "get coffee with Ana in my diary for thursday at 9am" schedule_event title "coffee with Ana" when "thursday at 9am"
    "store this as Recipes: two eggs, one lemon" save_note title "Recipes" body "two eggs, one lemon"
    "find the to-dos in my Budget note" extract_tasks title "Budget"
    "order me a pizza" none
    """
}

public enum ProposalError: Error, Equatable, CustomStringConvertible {
    case declined
    case unreadableDate(String)
    case missingDate(String)

    public var description: String {
        switch self {
        case .declined: "The request is outside the four things this engine can do."
        case .unreadableDate(let text): "\"\(text)\" is not a date this engine can read."
        case .missingDate(let title): "\"\(title)\" needs a start time."
        }
    }
}

extension Proposal {
    /// The bridge from words to a typed plan. Everything past here is plain code.
    public func plan(when clock: When) throws(ProposalError) -> Plan {
        var result: [Step] = []
        for (index, item) in steps.enumerated() {
            let after = index == 0 ? [] : ["s\(index)"]
            let step = Step(id: "s\(index + 1)", action: try action(item, clock), after: after)
            result.append(step)
        }
        return Plan(steps: result)
    }

    private func action(_ item: Item, _ clock: When) throws(ProposalError) -> Action {
        switch item.action {
        case "add_task":
            return .addTask(title: item.title, due: try date(item.when, clock))
        case "schedule_event":
            guard let start = try date(item.when, clock) else { throw .missingDate(item.title) }
            return .scheduleEvent(title: item.title, start: start, minutes: item.minutes == 0 ? 30 : item.minutes)
        case "save_note":
            return .saveNote(title: item.title, body: item.body)
        case "extract_tasks":
            return .extractTasks(note: item.title)
        default:
            throw .declined
        }
    }

    private func date(_ words: String, _ clock: When) throws(ProposalError) -> Date? {
        if words.isEmpty { return nil }
        guard let date = clock.resolve(words) else { throw .unreadableDate(words) }
        return date
    }
}
