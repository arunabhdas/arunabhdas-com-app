import Foundation

public struct Routed: Codable, Equatable, Sendable {
    public var request: String
    public var now: Date
    public var route: String
    public var plan: Plan
    public var hash: String
    public var raw: String?
    public var localTokens: Int
    public var cloudTokens: Int
    public var milliseconds: Double
}

public enum EngineError: Error, CustomStringConvertible {
    case noRoute
    case rejected(String)

    public var description: String {
        switch self {
        case .noRoute: "No rule matched, and no local model is set."
        case .rejected(let reason): reason
        }
    }
}

public struct Engine: Sendable {
    public let now: Date
    public let timeZone: TimeZone
    public let proposer: (any Proposer)?

    public init(now: Date, timeZone: TimeZone = .gmt, proposer: (any Proposer)? = nil) {
        self.now = now
        self.timeZone = timeZone
        self.proposer = proposer
    }

    /// Rules first. The model only hears what the rules could not read.
    public func plan(_ request: String) async throws -> Routed {
        let clock = When(now: now, timeZone: timeZone)
        let started = ContinuousClock.now

        if let plan = Rules(when: clock).plan(request) {
            return try seal(request, "rules", plan, nil, 0, started)
        }
        guard let proposer else { throw EngineError.noRoute }

        let reply = try await proposer.propose(request)
        let plan = try Self.decode(reply.raw, clock)
        return try seal(request, proposer.name, plan, reply.raw, reply.tokens, started)
    }

    /// Rebuilds a plan from a record without running any model.
    public static func replay(_ record: Routed, timeZone: TimeZone = .gmt) throws -> Plan {
        let clock = When(now: record.now, timeZone: timeZone)
        if let raw = record.raw { return try decode(raw, clock) }
        guard let plan = Rules(when: clock).plan(record.request) else { throw EngineError.noRoute }
        return plan
    }

    static func decode(_ raw: String, _ clock: When) throws -> Plan {
        let proposal = try JSONDecoder().decode(Proposal.self, from: Data(raw.utf8))
        do {
            return try proposal.plan(when: clock)
        } catch {
            throw EngineError.rejected(error.description)
        }
    }

    private func seal(
        _ request: String, _ route: String, _ plan: Plan, _ raw: String?, _ tokens: Int,
        _ started: ContinuousClock.Instant
    ) throws -> Routed {
        do {
            _ = try Validator(now: now).check(plan)
        } catch {
            throw EngineError.rejected(error.description)
        }
        let elapsed = started.duration(to: .now).components
        let ms = Double(elapsed.seconds) * 1_000 + Double(elapsed.attoseconds) / 1e15
        return Routed(
            request: request, now: now, route: route, plan: plan, hash: try fingerprint(plan),
            raw: raw, localTokens: tokens, cloudTokens: 0, milliseconds: ms
        )
    }
}
