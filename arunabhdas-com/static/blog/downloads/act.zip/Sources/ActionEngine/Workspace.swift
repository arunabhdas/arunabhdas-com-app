import Foundation

/// Every file the engine touches lives under one root.
public struct Workspace: Sendable {
    public let root: URL

    public init(root: URL) throws {
        self.root = root
        for folder in ["notes", "events", "plans"] {
            try FileManager.default.createDirectory(
                at: root.appending(path: folder), withIntermediateDirectories: true)
        }
    }

    public var tasks: URL { root.appending(path: "tasks.md") }
    public var journal: URL { root.appending(path: "journal.jsonl") }
    public var audit: URL { root.appending(path: "audit.jsonl") }
    public func note(_ title: String) -> URL { root.appending(path: "notes/\(Self.slug(title)).md") }
    public func plan(_ hash: String) -> URL { root.appending(path: "plans/\(hash).json") }

    /// Letters, digits, and hyphens only, so a title can never become a path.
    public static func slug(_ text: String) -> String {
        let words = text.lowercased().split { !($0.isASCII && ($0.isLetter || $0.isNumber)) }
        return words.isEmpty ? "untitled" : words.joined(separator: "-")
    }

    public func append(_ line: Data, to file: URL) throws {
        if !FileManager.default.fileExists(atPath: file.path) {
            FileManager.default.createFile(atPath: file.path, contents: nil)
        }
        let handle = try FileHandle(forWritingTo: file)
        defer { try? handle.close() }
        try handle.seekToEnd()
        try handle.write(contentsOf: line + Data("\n".utf8))
    }

    public func lines(of file: URL) -> [String] {
        guard let text = try? String(contentsOf: file, encoding: .utf8) else { return [] }
        return text.split(separator: "\n").map(String.init)
    }
}
