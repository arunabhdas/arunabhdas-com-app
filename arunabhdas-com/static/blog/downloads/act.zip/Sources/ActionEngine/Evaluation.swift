import Foundation

public struct Case: Codable, Sendable {
    public var request: String
    public var expect: [String]
    public var date: Date?
}

public enum Evaluation {
    public static func kind(_ action: Action) -> String {
        switch action {
        case .addTask: "addTask"
        case .scheduleEvent: "scheduleEvent"
        case .saveNote: "saveNote"
        case .extractTasks: "extractTasks"
        }
    }

    static func date(_ action: Action) -> Date? {
        switch action {
        case .addTask(_, let due): due
        case .scheduleEvent(_, let start, _): start
        default: nil
        }
    }

    public static func run(file: URL, engine: Engine) async throws -> String {
        let text = try String(contentsOf: file, encoding: .utf8)
        let cases = try text.split(separator: "\n").map {
            try decodeCanonical(Case.self, from: Data($0.utf8))
        }
        var routes: [String: (total: Int, right: Int, ms: Double, tokens: Int)] = [:]
        var wrong: [String] = []

        for item in cases {
            var route = "refused"
            var got = ["refused"]
            var right = false
            var ms = 0.0, tokens = 0
            do {
                let routed = try await engine.plan(item.request)
                route = routed.route
                ms = routed.milliseconds
                tokens = routed.localTokens
                got = routed.plan.steps.map { kind($0.action) }
                right = got == item.expect
                    && (item.date == nil || routed.plan.steps.first.flatMap { date($0.action) } == item.date)
            } catch {
                right = item.expect == ["refused"]
            }
            var row = routes[route] ?? (0, 0, 0, 0)
            row.total += 1
            row.right += right ? 1 : 0
            row.ms += ms
            row.tokens += tokens
            routes[route] = row
            if !right { wrong.append("  \(item.request)\n    wanted \(item.expect), got \(got)") }
        }

        var lines = ["route                     cases  right  avg ms   local tokens"]
        for (route, row) in routes.sorted(by: { $0.key < $1.key }) {
            let columns = [
                route.padding(toLength: 24, withPad: " ", startingAt: 0),
                String(format: "%5d  %5d  %7.2f  %6d", row.total, row.right, row.ms / Double(row.total), row.tokens),
            ]
            lines.append(columns.joined(separator: " "))
        }
        let right = routes.values.map(\.right).reduce(0, +)
        lines.append("\(right) of \(cases.count) right, 0 cloud tokens")
        if !wrong.isEmpty { lines.append("wrong:\n" + wrong.joined(separator: "\n")) }
        return lines.joined(separator: "\n")
    }
}
