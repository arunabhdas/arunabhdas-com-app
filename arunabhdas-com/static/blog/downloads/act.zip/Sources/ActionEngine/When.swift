import Foundation

/// Turns "friday at 3pm" into a date. Code owns the calendar, never the model.
public struct When: Sendable {
    public let now: Date
    public let calendar: Calendar

    public init(now: Date, timeZone: TimeZone = .gmt) {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = timeZone
        self.now = now
        self.calendar = calendar
    }

    static let days = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"]

    /// The phrase must be a date, a time, or both, and nothing else.
    public func resolve(_ phrase: String) -> Date? {
        let pattern = /^(?:(?:on |next )?(?<day>today|tomorrow|sunday|monday|tuesday|wednesday|thursday|friday|saturday))?\s*(?:(?:at )?(?<hour>\d{1,2})(?::(?<minute>\d{2}))?\s*(?<ampm>am|pm)?)?$/
        let text = phrase.lowercased().trimmingCharacters(in: .whitespaces)
        guard !text.isEmpty, let match = text.wholeMatch(of: pattern) else { return nil }

        var hour = 9, minute = 0
        if let raw = match.hour {
            hour = Int(raw)!
            minute = match.minute.map { Int($0)! } ?? 0
            if let ampm = match.ampm {
                guard (1...12).contains(hour) else { return nil }
                hour = hour % 12 + (ampm == "pm" ? 12 : 0)
            } else if match.minute == nil {
                return nil // "at 3" could be either. Do not guess.
            }
        }
        guard (0...23).contains(hour), (0...59).contains(minute) else { return nil }

        let today = calendar.startOfDay(for: now)
        var offset = 0
        switch match.day.map(String.init) {
        case nil, "today": offset = 0
        case "tomorrow": offset = 1
        case let name?:
            let target = Self.days.firstIndex(of: name)! + 1
            let current = calendar.component(.weekday, from: today)
            offset = (target - current + 7) % 7
            if offset == 0 { offset = 7 }
        }
        let day = calendar.date(byAdding: .day, value: offset, to: today)!
        return calendar.date(bySettingHour: hour, minute: minute, second: 0, of: day)
    }
}
