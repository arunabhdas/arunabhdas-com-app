import Foundation

public struct ModelReply: Sendable {
    public var raw: String
    public var tokens: Int
}

public protocol Proposer: Sendable {
    var name: String { get }
    func propose(_ request: String) async throws -> ModelReply
}

/// Runs any GGUF model on this machine. The grammar comes from the JSON schema,
/// so tokens that would break it are never sampled.
public struct LlamaProposer: Proposer {
    public let modelPath: String
    public var name: String { URL(filePath: modelPath).deletingPathExtension().lastPathComponent }

    public init(modelPath: String) { self.modelPath = modelPath }

    public func propose(_ request: String) async throws -> ModelReply {
        let log = FileManager.default.temporaryDirectory.appending(path: UUID().uuidString)
        FileManager.default.createFile(atPath: log.path, contents: nil)
        defer { try? FileManager.default.removeItem(at: log) }

        let process = Process()
        let output = Pipe()
        process.executableURL = URL(filePath: "/usr/bin/env")
        process.arguments = [
            "llama-completion", "-m", modelPath,
            "-sys", Proposal.instructions, "-p", request,
            "--json-schema", Proposal.schema,
            "--temp", "0", "--seed", "42", "-n", "256", "-c", "2048",
            "-st", "--no-display-prompt", "--simple-io", "--perf",
        ]
        process.standardOutput = output
        process.standardError = try FileHandle(forWritingTo: log)
        process.standardInput = FileHandle.nullDevice
        try process.run()
        let data = output.fileHandleForReading.readDataToEndOfFile()
        process.waitUntilExit()

        let text = String(decoding: data, as: UTF8.self)
        guard let start = text.firstIndex(of: "{"), let end = text.lastIndex(of: "}") else {
            throw CocoaError(.coderReadCorrupt)
        }
        let perf = (try? String(contentsOf: log, encoding: .utf8)) ?? ""
        return ModelReply(raw: String(text[start...end]), tokens: Self.tokens(in: perf))
    }

    /// llama.cpp ends its timings with "total time = ... / 412 tokens".
    static func tokens(in log: String) -> Int {
        log.matches(of: /total time.*\/\s+(\d+) tokens/).last.flatMap { Int($0.1) } ?? 0
    }
}
