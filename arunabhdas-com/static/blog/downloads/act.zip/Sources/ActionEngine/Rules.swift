import Foundation

/// Tier 0. Known request shapes become plans with no model at all.
public struct Rules: Sendable {
    public let when: When

    public init(when: When) { self.when = when }

    public func plan(_ request: String) -> Plan? {
        let parts = request
            .split(separator: /\s+(?:and\s+)?then\s+/)
            .map { $0.trimmingCharacters(in: .whitespaces) }
        var steps: [Step] = []
        for (index, part) in parts.enumerated() {
            guard let action = action(part) else { return nil }
            let after = index == 0 ? [] : ["s\(index)"]
            steps.append(Step(id: "s\(index + 1)", action: action, after: after))
        }
        return steps.isEmpty ? nil : Plan(steps: steps)
    }

    func action(_ text: String) -> Action? {
        if let m = text.wholeMatch(of: /(?i)(?:remind me to|add a task to|add task:?|todo:?)\s+(?<rest>.+)/) {
            let (title, phrase) = splitWhen(String(m.rest))
            if let phrase {
                guard let due = when.resolve(phrase) else { return nil }
                return .addTask(title: title, due: due)
            }
            return .addTask(title: title, due: nil)
        }
        if let m = text.wholeMatch(of: /(?i)(?:schedule|book)\s+(?!me\b)(?<rest>.+?)(?:\s+for\s+(?<n>\d+)\s*(?<unit>minutes?|mins?|hours?))?/) {
            let (title, phrase) = splitWhen(String(m.rest))
            guard let phrase, let start = when.resolve(phrase) else { return nil }
            var minutes = 30
            if let n = m.n.flatMap({ Int($0) }) {
                minutes = m.unit?.lowercased().hasPrefix("hour") == true ? n * 60 : n
            }
            return .scheduleEvent(title: title, start: start, minutes: minutes)
        }
        if let m = text.wholeMatch(of: /(?i)(?:save a note|save note|note)(?:\s+(?:called|titled))?\s+(?<title>[^:]+):\s*(?<body>.+)/) {
            return .saveNote(title: String(m.title), body: String(m.body))
        }
        if let m = text.wholeMatch(of: /(?i)extract tasks from\s+(?<a>.+)|turn\s+(?<b>.+)\s+into tasks/) {
            return .extractTasks(note: String(m.a ?? m.b ?? ""))
        }
        return nil
    }

    /// Splits "send the invoice friday at 3pm" into a title and a date phrase.
    func splitWhen(_ text: String) -> (String, String?) {
        let tail = /(?i)\s+(?<phrase>(?:on |next )?(?:today|tomorrow|sunday|monday|tuesday|wednesday|thursday|friday|saturday)(?:\s+(?:at )?\d{1,2}(?::\d{2})?\s*(?:am|pm)?)?|at \d{1,2}(?::\d{2})?\s*(?:am|pm)?)$/
        guard let m = text.firstMatch(of: tail) else { return (text, nil) }
        return (String(text[..<m.range.lowerBound]), String(m.phrase))
    }
}
