import CryptoKit
import Foundation

/// One value, one byte sequence: sorted keys, fixed date format.
public func canonicalJSON<T: Encodable>(_ value: T) throws -> Data {
    let encoder = JSONEncoder()
    encoder.outputFormatting = [.sortedKeys, .withoutEscapingSlashes]
    encoder.dateEncodingStrategy = .iso8601
    return try encoder.encode(value)
}

public func fingerprint<T: Encodable>(_ value: T) throws -> String {
    let digest = SHA256.hash(data: try canonicalJSON(value))
    return digest.prefix(6).map { String(format: "%02x", $0) }.joined()
}

public func decodeCanonical<T: Decodable>(_ type: T.Type, from data: Data) throws -> T {
    let decoder = JSONDecoder()
    decoder.dateDecodingStrategy = .iso8601
    return try decoder.decode(type, from: data)
}
