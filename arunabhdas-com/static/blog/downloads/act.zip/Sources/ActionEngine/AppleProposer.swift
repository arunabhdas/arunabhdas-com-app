#if canImport(FoundationModels)
import Foundation
import FoundationModels

/// The same contract on Apple's built-in model. Nothing to download.
@available(macOS 26, iOS 26, *)
public struct AppleProposer: Proposer {
    @Generable
    struct Draft {
        @Generable
        struct Item {
            @Guide(.anyOf(["add_task", "schedule_event", "save_note", "extract_tasks", "none"]))
            var action: String
            var title: String
            @Guide(description: "The date in the user's words, or empty")
            var when: String
            @Guide(.range(0...480))
            var minutes: Int
            var body: String
        }
        @Guide(.count(1...4))
        var steps: [Item]
    }

    public let name = "apple-on-device"

    public init() {}

    public static var isAvailable: Bool {
        if case .available = SystemLanguageModel.default.availability { return true }
        return false
    }

    public func propose(_ request: String) async throws -> ModelReply {
        let session = LanguageModelSession(instructions: Proposal.instructions)
        let options = GenerationOptions(samplingMode: .greedy)
        let draft = try await session.respond(to: request, generating: Draft.self, options: options).content
        let proposal = Proposal(steps: draft.steps.map {
            .init(action: $0.action, title: $0.title, when: $0.when, minutes: $0.minutes, body: $0.body)
        })
        let raw = String(decoding: try canonicalJSON(proposal), as: UTF8.self)
        return ModelReply(raw: raw, tokens: 0)
    }
}
#endif
