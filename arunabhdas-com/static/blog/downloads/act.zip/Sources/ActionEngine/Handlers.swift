import Foundation

public enum HandlerError: Error, CustomStringConvertible {
    case noteExists(String)
    case noteMissing(String)

    public var description: String {
        switch self {
        case .noteExists(let name): "A different note called \(name) already exists."
        case .noteMissing(let name): "There is no note called \(name)."
        }
    }
}

/// Each handler is safe to run twice with the same key.
struct Handlers {
    let workspace: Workspace

    func perform(_ action: Action, key: String) throws -> String {
        switch action {
        case .addTask(let title, let due):
            return try addTask(title, due: due, key: key)
        case .scheduleEvent(let title, let start, let minutes):
            return try writeEvent(title, start: start, minutes: minutes, key: key)
        case .saveNote(let title, let body):
            return try saveNote(title, body: body)
        case .extractTasks(let note):
            return try extractTasks(from: note, key: key)
        }
    }

    func addTask(_ title: String, due: Date?, key: String) throws -> String {
        let marker = "<!-- act:\(key) -->"
        if workspace.lines(of: workspace.tasks).contains(where: { $0.hasSuffix(marker) }) {
            return "tasks.md (already there)"
        }
        let date = due.map { " (due \($0.formatted(.iso8601)))" } ?? ""
        try workspace.append(Data("- [ ] \(title)\(date) \(marker)".utf8), to: workspace.tasks)
        return "tasks.md"
    }

    func writeEvent(_ title: String, start: Date, minutes: Int, key: String) throws -> String {
        let stamp = Date.ISO8601FormatStyle(dateSeparator: .omitted, timeSeparator: .omitted, timeZone: .gmt)
        let end = start.addingTimeInterval(Double(minutes) * 60)
        let summary = title
            .replacing("\\", with: "\\\\").replacing(";", with: "\\;").replacing(",", with: "\\,")
        let lines = [
            "BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//act//EN", "BEGIN:VEVENT",
            "UID:\(key)@act", "DTSTAMP:\(stamp.format(start))",
            "DTSTART:\(stamp.format(start))", "DTEND:\(stamp.format(end))",
            "SUMMARY:\(summary)", "END:VEVENT", "END:VCALENDAR", "",
        ]
        let name = "events/\(Workspace.slug(title))-\(key).ics"
        try Data(lines.joined(separator: "\r\n").utf8).write(to: workspace.root.appending(path: name), options: .atomic)
        return name
    }

    func saveNote(_ title: String, body: String) throws -> String {
        let file = workspace.note(title)
        let content = "# \(title)\n\n\(body)\n"
        if let existing = try? String(contentsOf: file, encoding: .utf8) {
            guard existing == content else { throw HandlerError.noteExists(title) }
            return "notes/\(file.lastPathComponent) (already there)"
        }
        try Data(content.utf8).write(to: file, options: .atomic)
        return "notes/\(file.lastPathComponent)"
    }

    func extractTasks(from note: String, key: String) throws -> String {
        guard let text = try? String(contentsOf: workspace.note(note), encoding: .utf8) else {
            throw HandlerError.noteMissing(note)
        }
        let found = text.split(whereSeparator: \.isNewline).compactMap { line in
            line.wholeMatch(of: /\s*(?:TODO:|- \[ \])\s*(.+)/).map { String($0.1) }
        }
        for (index, title) in found.enumerated() {
            _ = try addTask(title, due: nil, key: "\(key)-\(index)")
        }
        return "tasks.md (\(found.count) from \(note))"
    }
}
