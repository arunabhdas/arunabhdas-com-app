// swift-tools-version: 6.2
import PackageDescription

let package = Package(
    name: "act",
    platforms: [.macOS(.v26)],
    targets: [
        .target(name: "ActionEngine"),
        .executableTarget(name: "act", dependencies: ["ActionEngine"]),
        .testTarget(name: "ActionEngineTests", dependencies: ["ActionEngine"]),
    ]
)
