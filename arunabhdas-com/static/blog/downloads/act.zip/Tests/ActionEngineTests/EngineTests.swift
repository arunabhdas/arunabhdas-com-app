import Foundation
import Testing

@testable import ActionEngine

let now = try! Date("2026-11-05T09:00:00Z", strategy: .iso8601)
let friday3pm = try! Date("2026-11-06T15:00:00Z", strategy: .iso8601)

func scratch() throws -> Workspace {
    try Workspace(root: FileManager.default.temporaryDirectory.appending(path: UUID().uuidString))
}

@Suite struct Dates {
    let when = When(now: now)

    @Test func resolvesWords() {
        #expect(when.resolve("friday at 3pm") == friday3pm)
        #expect(when.resolve("tomorrow 15:00") == friday3pm)
    }

    @Test func refusesToGuess() {
        #expect(when.resolve("at 3") == nil)
        #expect(when.resolve("when I get in") == nil)
        #expect(when.resolve("13pm") == nil)
    }
}

@Suite struct Tier0 {
    let rules = Rules(when: When(now: now))

    @Test func readsKnownShapes() {
        let plan = rules.plan("remind me to send the invoice friday at 3pm")
        #expect(plan?.steps == [Step(id: "s1", action: .addTask(title: "send the invoice", due: friday3pm))])
    }

    @Test func chainsSteps() {
        let plan = rules.plan("save a note called Standup: TODO: ship it then extract tasks from Standup")
        #expect(plan?.steps.count == 2)
        #expect(plan?.steps[1].after == ["s1"])
    }

    @Test func leavesTheRestAlone() {
        #expect(rules.plan("nudge me about the invoice when I get in") == nil)
        #expect(rules.plan("book me a flight to Lisbon on friday") == nil)
        #expect(rules.plan("turn off the lights") == nil)
    }
}

@Suite struct Gate {
    let validator = Validator(now: now)

    @Test func catchesLoops() {
        let plan = Plan(steps: [
            Step(id: "a", action: .saveNote(title: "A", body: "x"), after: ["b"]),
            Step(id: "b", action: .saveNote(title: "B", body: "x"), after: ["a"]),
        ])
        #expect(throws: PlanError.cycle) { try validator.check(plan) }
    }

    @Test func catchesThePast() {
        let plan = Plan(steps: [Step(id: "a", action: .addTask(title: "Late", due: .distantPast))])
        #expect(throws: PlanError.self) { try validator.check(plan) }
    }

    @Test func modelCannotInventAnAction() throws {
        let raw = #"{"steps":[{"action":"delete_files","title":"~","when":"","minutes":0,"body":""}]}"#
        #expect(throws: EngineError.self) { try Engine.decode(raw, When(now: now)) }
    }
}

@Suite struct Effects {
    let plan = Plan(steps: [
        Step(id: "s1", action: .addTask(title: "Send the invoice", due: friday3pm)),
        Step(id: "s2", action: .scheduleEvent(title: "Review", start: friday3pm, minutes: 45), after: ["s1"]),
    ])

    @Test func runningTwiceChangesNothing() throws {
        let workspace = try scratch()
        let executor = Executor(workspace: workspace, now: now)
        try executor.run(plan)
        let second = try executor.run(plan)
        #expect(second.allSatisfy { $0.status == "skipped" })
        #expect(workspace.lines(of: workspace.tasks).count == 1)
    }

    @Test func aCrashNeverDuplicates() throws {
        let workspace = try scratch()
        let crashing = Executor(workspace: workspace, now: now, crashAfter: "s1")
        #expect(throws: Executor.Crash.self) { try crashing.run(plan) }

        try Executor(workspace: workspace, now: now).run(plan)
        #expect(workspace.lines(of: workspace.tasks).count == 1)
    }

    @Test func aTitleCannotEscapeTheWorkspace() {
        #expect(Workspace.slug("../../.ssh/authorized_keys") == "ssh-authorized-keys")
    }
}

@Test func readsTokenCountFromLlamaTimings() {
    let log = """
    prompt eval time =  16.83 ms /    13 tokens
           eval time =  27.04 ms /     7 runs
          total time =  46.43 ms /    20 tokens
    """
    #expect(LlamaProposer.tokens(in: log) == 20)
}

@Suite struct Replay {
    struct Canned: Proposer {
        let name = "canned"
        func propose(_ request: String) async throws -> ModelReply {
            let raw = #"{"steps":[{"action":"add_task","title":"Pay rent","when":"friday at 3pm","minutes":0,"body":""}]}"#
            return ModelReply(raw: raw, tokens: 40)
        }
    }

    @Test func aRecordRebuildsTheSamePlan() async throws {
        let routed = try await Engine(now: now, proposer: Canned()).plan("sort out rent by friday afternoon")
        #expect(routed.route == "canned")
        #expect(routed.cloudTokens == 0)
        #expect(try fingerprint(try Engine.replay(routed)) == routed.hash)
    }
}
